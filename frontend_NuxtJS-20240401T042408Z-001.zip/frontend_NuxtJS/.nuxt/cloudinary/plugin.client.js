import { ClientApi } from '~cloudinary/client'

const configuration = {
  "privateCdn": false,
  "cloudName": "duong1310",
  "apiKey": "261888578694677",
  "apiSecret": "rUg4bFe47s6R-H6qqd6JIgMsL7Q",
  "useComponent": true,
  "secure": true
}

import Vue from 'vue'
import Cloudinary from 'cloudinary-vue'

Vue.use(Cloudinary, {
  configuration
})

export default function (context, inject) {
  const cloudinary = new ClientApi(configuration)

  context.$cloudinary = cloudinary
  inject('cloudinary', cloudinary)
}