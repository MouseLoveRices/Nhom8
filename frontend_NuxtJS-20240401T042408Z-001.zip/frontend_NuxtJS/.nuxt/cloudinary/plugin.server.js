import { ServerApi } from "~cloudinary/server";

const configuration = {
  "privateCdn": false,
  "cloudName": "duong1310",
  "apiKey": "261888578694677",
  "apiSecret": "rUg4bFe47s6R-H6qqd6JIgMsL7Q",
  "useComponent": true,
  "secure": true
}

export default function(context, inject) {
  const cloudinary = new ServerApi(configuration);

  context.$cloudinary = cloudinary;
  inject("cloudinary", cloudinary);
}