export { default as Products } from '../..\\components\\Products.vue'
export { default as CartTableOder } from '../..\\components\\cart\\TableOder.vue'
export { default as Carousel } from '../..\\components\\carousel\\Carousel.vue'
export { default as ContactForm } from '../..\\components\\contact\\ContactForm.vue'
export { default as Footer } from '../..\\components\\footer\\Footer.vue'
export { default as Header } from '../..\\components\\header\\Header.vue'
export { default as Comment } from '../..\\components\\comment\\Comment.vue'
export { default as AdminContent } from '../..\\components\\admin\\Content.vue'
export { default as AccountChangePassword } from '../..\\components\\account\\ChangePassword.vue'
export { default as AccountEditProfile } from '../..\\components\\account\\EditProfile.vue'
export { default as AccountProfile } from '../..\\components\\account\\Profile.vue'
export { default as AccountTabAccount } from '../..\\components\\account\\TabAccount.vue'
export { default as AccountUserChart } from '../..\\components\\account\\UserChart.vue'
export { default as Hero } from '../..\\components\\hero\\Hero.vue'
export { default as HeroSubHero } from '../..\\components\\hero\\SubHero.vue'
export { default as Menu } from '../..\\components\\menu\\Menu.vue'
export { default as ModalsearchListOne } from '../..\\components\\modalsearch\\ListOne.vue'
export { default as ModalsearchModalSearch } from '../..\\components\\modalsearch\\ModalSearch.vue'
export { default as ModalsearchOneProduct } from '../..\\components\\modalsearch\\OneProduct.vue'
export { default as OrderItemOrder } from '../..\\components\\order\\ItemOrder.vue'
export { default as OrderTabOrder } from '../..\\components\\order\\TabOrder.vue'
export { default as ModalBillingInfo } from '../..\\components\\modal\\BillingInfo.vue'
export { default as ModalCheckout } from '../..\\components\\modal\\Checkout.vue'
export { default as ModalLogin } from '../..\\components\\modal\\Login.vue'
export { default as ModalQuickView } from '../..\\components\\modal\\QuickView.vue'
export { default as ModalSignup } from '../..\\components\\modal\\Signup.vue'
export { default as ModalWishList } from '../..\\components\\modal\\WishList.vue'
export { default as ProductsListContainer } from '../..\\components\\products_list\\ProductsListContainer.vue'
export { default as Radio } from '../..\\components\\radio\\Radio.vue'
export { default as Search } from '../..\\components\\search\\Search.vue'
export { default as SubheaderDropProfile } from '../..\\components\\subheader\\DropProfile.vue'
export { default as Subheader } from '../..\\components\\subheader\\Subheader.vue'
export { default as TabProduct } from '../..\\components\\tab\\TabProduct.vue'
export { default as WishlistTableWishlist } from '../..\\components\\wishlist\\TableWishlist.vue'
export { default as AdminChartLineChart } from '../..\\components\\admin\\chart\\LineChart.vue'
export { default as AdminChartPieChart } from '../..\\components\\admin\\chart\\PieChart.vue'
export { default as AdminDocsSnippet } from '../..\\components\\admin\\docs\\Snippet.vue'
export { default as AdminContactTableContact } from '../..\\components\\admin\\contact\\TableContact.vue'
export { default as AdminDashboardLayout } from '../..\\components\\admin\\dashboard\\Layout.vue'
export { default as AdminOrdersModalDetail } from '../..\\components\\admin\\orders\\ModalDetail.vue'
export { default as AdminOrdersTableOrder } from '../..\\components\\admin\\orders\\TableOrder.vue'
export { default as AdminOrdersTabOrder } from '../..\\components\\admin\\orders\\TabOrder.vue'
export { default as AdminRecycelbinBinProduct } from '../..\\components\\admin\\recycelbin\\BinProduct.vue'
export { default as AdminRecycelbinBinTab } from '../..\\components\\admin\\recycelbin\\BinTab.vue'
export { default as AdminRecycelbinBinUser } from '../..\\components\\admin\\recycelbin\\BinUser.vue'
export { default as AdminUsersTableUser } from '../..\\components\\admin\\users\\TableUser.vue'
export { default as AdminProductsAddProduct } from '../..\\components\\admin\\products\\AddProduct.vue'
export { default as AdminProductsEditProduct } from '../..\\components\\admin\\products\\EditProduct.vue'
export { default as AdminProductsTableProduct } from '../..\\components\\admin\\products\\TableProduct.vue'
export { default as AdminDocsIconsFileIcon } from '../..\\components\\admin\\docs\\icons\\FileIcon.vue'
export { default as AdminDocsIconsFolderIcon } from '../..\\components\\admin\\docs\\icons\\FolderIcon.vue'
export { default as AdminDocsIconsVueIcon } from '../..\\components\\admin\\docs\\icons\\VueIcon.vue'
export { default as AdminDashboardTopnavigation } from '../..\\components\\admin\\dashboard\\topnavigation\\Index.vue'
export { default as AdminDashboardProviderOverlay } from '../..\\components\\admin\\dashboard\\provider\\Overlay.vue'
export { default as AdminDashboardProvider } from '../..\\components\\admin\\dashboard\\provider\\Provider.vue'
export { default as AdminDashboardSidenavigationHeader } from '../..\\components\\admin\\dashboard\\sidenavigation\\Header.vue'
export { default as AdminDashboardSidenavigation } from '../..\\components\\admin\\dashboard\\sidenavigation\\Index.vue'
export { default as AdminDashboardSidenavigationItem } from '../..\\components\\admin\\dashboard\\sidenavigation\\Item.vue'
export { default as AdminDashboardSidenavigationItems } from '../..\\components\\admin\\dashboard\\sidenavigation\\Items.vue'
export { default as AdminDashboardSidenavigationIconsContact } from '../..\\components\\admin\\dashboard\\sidenavigation\\icons\\Contact.vue'
export { default as AdminDashboardSidenavigationIconsDocumentation } from '../..\\components\\admin\\dashboard\\sidenavigation\\icons\\Documentation.vue'
export { default as AdminDashboardSidenavigationIconsMedias } from '../..\\components\\admin\\dashboard\\sidenavigation\\icons\\Medias.vue'
export { default as AdminDashboardSidenavigationIconsRecycleBin } from '../..\\components\\admin\\dashboard\\sidenavigation\\icons\\RecycleBin.vue'
export { default as AdminDashboardSidenavigationIconsServers } from '../..\\components\\admin\\dashboard\\sidenavigation\\icons\\Servers.vue'
export { default as AdminDashboardSidenavigationIconsSettings } from '../..\\components\\admin\\dashboard\\sidenavigation\\icons\\Settings.vue'
export { default as AdminDashboardSidenavigationIconsTerminal } from '../..\\components\\admin\\dashboard\\sidenavigation\\icons\\Terminal.vue'
export { default as AdminDashboardSidenavigationIconsUsers } from '../..\\components\\admin\\dashboard\\sidenavigation\\icons\\Users.vue'

// nuxt/nuxt.js#8607
function wrapFunctional(options) {
  if (!options || !options.functional) {
    return options
  }

  const propKeys = Array.isArray(options.props) ? options.props : Object.keys(options.props || {})

  return {
    render(h) {
      const attrs = {}
      const props = {}

      for (const key in this.$attrs) {
        if (propKeys.includes(key)) {
          props[key] = this.$attrs[key]
        } else {
          attrs[key] = this.$attrs[key]
        }
      }

      return h(options, {
        on: this.$listeners,
        attrs,
        props,
        scopedSlots: this.$scopedSlots,
      }, this.$slots.default)
    }
  }
}
