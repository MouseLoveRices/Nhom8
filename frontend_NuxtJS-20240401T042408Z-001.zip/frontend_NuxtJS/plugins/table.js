import SmartTable from 'vuejs-smart-table'
import Vue from 'vue'

Vue.use(SmartTable)
